export const environment = {
    apiUrl: "http://ghaprdorassrv/vfs-backend/public/api",
    userRoles: ['ADMIN', 'SUPERVISOR', 'TELLER', 'REPORTER', 'USER_MANAGER'],
    receiptsUrl: "http://ghaprdorassrv/vfs-backend/public/receipts"
};
