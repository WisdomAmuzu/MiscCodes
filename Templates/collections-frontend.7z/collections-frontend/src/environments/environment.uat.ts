export const environment = {
    production: false,
    apiUrl: "http://ghauatwebserver:8000/vfs-backend/public/api",
    userRoles: ['ADMIN', 'SUPERVISOR', 'TELLER', 'REPORTER', 'USER_MANAGER'],
    receiptsUrl: "http://ghauatwebserver:8000/vfs-backend/public/receipts"
};
