export const environment = {
    production: false,
    apiUrl: "http://localhost:8000/api",
    userRoles: ['ADMIN', 'SUPERVISOR', 'TELLER', 'REPORTER', 'USER_MANAGER'],
    receiptsUrl: "http://localhost:8000/receipts"
};
