import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-teller-reports',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './teller-reports.component.html',
  styleUrls: ['./teller-reports.component.css']
})
export class TellerReportsComponent {

}
