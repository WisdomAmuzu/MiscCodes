import { Component, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

import { AuthService } from 'src/app/services/auth/auth.service';
import { LoginPayload, LoginSuccResonse } from 'src/app/utils/types';
import { MatIconModule } from '@angular/material/icon';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    NgxSpinnerModule,

  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnDestroy {
  private subscription: Subscription = new Subscription();
  user = signal({})
  showPassword = false;
  errorMsg = '';
  loginForm = this.fb.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  constructor(
    private auth: AuthService, 
    private fb: FormBuilder,
    private spinner: NgxSpinnerService,
    private router: Router
  ) {}

  ngOnDestroy(): void {
      this.subscription.unsubscribe()
  }

  authenticate(payload: LoginPayload) {
    this.spinner.show()
    this.subscription.add(
      this.auth.authenticate(payload).subscribe({
        next: (results: LoginSuccResonse) => {
          this.user.set(results.user)
          this.spinner.hide()
          const usergroup = results.user.usergroup
          if (usergroup === "ADMIN" || usergroup === "REPORTER") {
            this.router.navigate(['/admin/reports'])
          }
          if (usergroup === "TELLER" || usergroup === "SUPERVISOR") {
            this.router.navigate(['/reports'])
          }
          if (usergroup === "USER_MANAGER") {
            this.router.navigate(['/users'])
          }
          
        },
        error: error => {
          this.handleError(error)
        }
      }) 
    )
    
  }

  handleSubmit() {
    const payload = this.loginForm.value as LoginPayload
    this.authenticate(payload)
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert("Session expired")
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage()
      this.auth.loginSignal.set(false)
      // this.router.navigate(['/login'])
      this.refresh()
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource")
    }
    if (error.status == 404) {
      alert(error.error.message)
    }
    if (error.status == 500) {
      alert(error.error.message)
    }
  }

  refresh(): void {
    window.location.reload();
  }

}
