import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Institution } from '../../../utils/types';
import { InstitutionsService } from 'src/app/services/institutions/institutions.service';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-update-institution',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    NgxSpinnerModule,
  ],
  templateUrl: './update-institution.component.html',
  styleUrls: ['./update-institution.component.css'],
})
export class UpdateInstitutionComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  institution?: Institution;
  institutionForm = this.fb.group({
    name: ['', [Validators.required]],
  });

  constructor(
    private fb: FormBuilder,
    private institutionsService: InstitutionsService,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
    private router: Router,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    Promise.all([this.fetchInstitution(+id!)]).then();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
      
  }

  fetchInstitution(id: number) {
    this.subscription.add(
      this.institutionsService.fetchInstitution(id).subscribe({
        next: (result: any) => {
          this.institution = result.institution;
          this.institutionForm.patchValue({
            name: result.institution.name,
          });
        },
        error: (error: any) => {
          this.handleError(error);
        },
      })
    )
    
  }

  updateInstitution(institution: Institution) {
    this.spinner.show();
    this.subscription.add(
      this.institutionsService.updateInstitution(institution).subscribe({
        next: (result: any) => {
          alert('Institution updated successfully');
          this.spinner.hide();
          this.router.navigate(['/institutions']);
        },
        error: (error: any) => {
          this.handleError(error);
        },
      })
    )
    
  }

  handleSubmit() {
    const institution = this.institutionForm.value as Institution;
    institution.id = this.institution?.id;
    this.updateInstitution(institution);
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
