import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { BranchesService } from 'src/app/services/branches/branches.service';
import { Branch, Institution, User } from 'src/app/utils/types';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute  } from '@angular/router';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-update-branch',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    NgxSpinnerModule,
    MatSelectModule,
  ],
  templateUrl: './update-branch.component.html',
  styleUrls: ['./update-branch.component.css']
})
export class UpdateBranchComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  branch?: Branch
  branchForm = this.fb.group({
    name: ['', Validators.required],
    branchcode: [''],
    suspaccno: ['', Validators.required],
    // ipaddress: [''],
  })

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private branchesService: BranchesService,
    private spinner: NgxSpinnerService,
    private auth: AuthService,

    
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id')
    Promise.all([this.fetchBranch(+id!)]).then()
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
      
  }

  fetchBranch(id: number) {
    this.subscription.add(
      this.branchesService.fetchBranch(id).subscribe({
        next: (result: any) => {
          this.branch = result.branch;
          this.branchForm.patchValue({
            name: result.branch.name,
            branchcode: result.branch.branchcode,
            suspaccno: result.branch.suspaccno,
          })
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error)
        }
      })
    )
    
  }
  
  updateBranch(branch: Branch) {
    this.spinner.show()
    this.subscription.add(
      this.branchesService.updateBranch(branch).subscribe({
        next: (result: any) => {
          alert("Branch Updated Successfully")
          this.spinner.hide()
          this.router.navigate(['/branches'])
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error)
        }
      })
    )
    
  }

  handleSubmit() {
    const branch = this.branchForm.value as Branch
    branch.id = this.branch?.id
    this.updateBranch(branch)
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide()
    if (error.status == 401) {
      alert("Session expired")
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.router.navigateByUrl('/login')
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource")
    }
    if (error.status == 500) {
      alert(error.error.message)
    }
  }
}
