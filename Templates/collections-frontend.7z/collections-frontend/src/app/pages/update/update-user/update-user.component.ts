import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { Branch, User, UserPayload } from 'src/app/utils/types';
import { MatSelectModule } from '@angular/material/select';
import { BranchesService } from 'src/app/services/branches/branches.service';
import { AuthService } from 'src/app/services/auth/auth.service';
import { UsersService } from 'src/app/services/users/users.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-update-user',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    NgxSpinnerModule,
  ],
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css'],
})
export class UpdateUserComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  statuses = ['Active', 'Not Active'];
  branches?: Branch[];
  user?: User;
  usergroups = environment.userRoles;

  userForm = this.fb.group({
    username: ['', [Validators.required]],
    usergroup: ['', [Validators.required]],
    fullname: ['', [Validators.required]],
    branch: [''],
    initials: ['', [Validators.required]],
    status: ['Active', [Validators.required]],
  });

  constructor(
    private auth: AuthService,
    private fb: FormBuilder,
    private branchService: BranchesService,
    private userService: UsersService,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    Promise.all([this.fetchUser(+id!), this.fetchBranches()]);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
      
  }

  fetchUser(id: number) {
    this.subscription.add(
      this.userService.fetchUser(id).subscribe({
        next: (result: any) => {
          this.user = result.user;
          this.userForm.patchValue({
            username: result.user.username,
            usergroup: result.user.usergroup,
            fullname: result.user.fullname,
            branch: result.user.branch,
            initials: result.user.initials,
            status: result.user.status,
          });
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  fetchBranches() {
    this.subscription.add(
      this.branchService.fetchBranches().subscribe({
        next: (result: any) => {
          this.branches = result.branches;
        },
        error: (error) => {
          this.handleError(error);
        },
      })
    )
    
  }

  updateUser(user: UserPayload) {
    this.spinner.show();
    this.subscription.add(
      this.userService.updateUser(user).subscribe({
        next: (result: any) => {
          alert('User updated successfully');
          this.spinner.hide();
          this.router.navigate(['/users']);
        },
        error: (error) => {
          this.handleError(error);
        },
      })
    )
    
  }

  handleSubmit() {
    const user = this.userForm.value as UserPayload;
    user.id = this.user?.id;
    this.updateUser(user);
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
