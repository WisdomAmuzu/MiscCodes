import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { ChargesService } from 'src/app/services/charges/charges.service';
import { InstitutionsService } from 'src/app/services/institutions/institutions.service';
import { PaymenttypeService } from 'src/app/services/paymenttype/paymenttype.service';
import {
  Charge,
  ChargePayload,
  Institution,
  PaymentType,
} from 'src/app/utils/types';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-update-charge',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    NgxSpinnerModule,
    MatInputModule,
  ],
  templateUrl: './update-charge.component.html',
  styleUrls: ['./update-charge.component.css'],
})
export class UpdateChargeComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  paymentTypes?: PaymentType[];
  charge?: Charge;
  chargeForm = this.fb.group({
    name: ['', Validators.required],
    paymenttype: ['', Validators.required],
    institution: ['', Validators.required],
    amount: [0, Validators.required],
    // mandatory: ['', Validators.required],
  });

  constructor(
    private fb: FormBuilder,
    private institutionService: InstitutionsService,
    private paymentTypeService: PaymenttypeService,
    private chargeService: ChargesService,
    private route: ActivatedRoute,
    private router: Router,
    private spinner: NgxSpinnerService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    Promise.all([this.fetchCharge(+id!)]).then();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
  }

  fetchCharge(id: number) {
    this.subscription.add(
      this.chargeService.fetchCharge(id).subscribe({
        next: (result: any) => {
          this.charge = result.charge;
          this.chargeForm.patchValue({
            name: result.charge.name,
            paymenttype: result.charge.paymenttype,
            institution: result.charge.institution,
            amount: result.charge.amount,
          });
          this.fetchPaymentTypes(result.charge.institution);
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  fetchPaymentTypes(institution: string) {
    this.subscription.add(
      this.paymentTypeService.fetchPaymentTypes(institution).subscribe({
        next: (result: any) => {
          this.paymentTypes = result.paymenttypes;
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  updateCharge(charge: ChargePayload) {
    this.spinner.show();
    this.subscription.add(
      this.chargeService.updateCharge(charge).subscribe({
        next: (result: any) => {
          alert('Charge updated successfully');
          this.spinner.hide();
          this.router.navigate(['/charges']);
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  handleSubmit() {
    const charge = this.chargeForm.value as ChargePayload;
    charge.id = this.charge?.id;
    this.updateCharge(charge);
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
