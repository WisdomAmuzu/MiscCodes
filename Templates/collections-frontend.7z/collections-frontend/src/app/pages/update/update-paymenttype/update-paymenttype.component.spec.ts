import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePaymenttypeComponent } from './update-paymenttype.component';

describe('UpdatePaymenttypeComponent', () => {
  let component: UpdatePaymenttypeComponent;
  let fixture: ComponentFixture<UpdatePaymenttypeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [UpdatePaymenttypeComponent]
    });
    fixture = TestBed.createComponent(UpdatePaymenttypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
