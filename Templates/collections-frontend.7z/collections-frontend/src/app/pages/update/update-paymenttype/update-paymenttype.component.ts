import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { BranchesService } from 'src/app/services/branches/branches.service';
import { InstitutionsService } from 'src/app/services/institutions/institutions.service';
import {
  Branch,
  Institution,
  Payment,
  PaymentType,
  PaymentTypePayload,
  User,
} from 'src/app/utils/types';
import { AuthService } from 'src/app/services/auth/auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { PaymenttypeService } from 'src/app/services/paymenttype/paymenttype.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-update-paymenttype',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    NgxSpinnerModule,
    MatSelectModule,
  ],
  templateUrl: './update-paymenttype.component.html',
  styleUrls: ['./update-paymenttype.component.css'],
})
export class UpdatePaymenttypeComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  institutions?: Institution[];
  paymentType?: PaymentType;
  paymentTypeForm = this.fb.group({
    name: ['', Validators.required],
    institution: ['', Validators.required],
    accountno: ['', Validators.required],
  });

  constructor(
    private auth: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private branchesService: BranchesService,
    private institutionsService: InstitutionsService,
    private paymentTypeService: PaymenttypeService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    Promise.all([this.fetchInstitutions(), this.fetchPaymentType(+id!)]).then();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
      
  }

  fetchPaymentType(id: number) {
    this.subscription.add(
      this.paymentTypeService.fetchPaymentType(id).subscribe({
        next: (result: any) => {
          (this.paymentType = result.paymenttype),
            this.paymentTypeForm.patchValue({
              name: result.paymenttype.name,
              institution: result.paymenttype.institution,
              accountno: result.paymenttype.accountno,
            });
        },
        error: (error: any) => {
          this.handleError(error);
        },
      })
    )
    
  }

  fetchInstitutions() {
    this.subscription.add(
      this.institutionsService.fetchInstitutionsAdmin().subscribe({
        next: (result: any) => {
          this.institutions = result.institutions;
        },
        error: (error: any) => {
          this.handleError(error);
        },
      })
    )
    
  }

  updatePaymentType(paymenttype: PaymentTypePayload) {
    this.spinner.show();
    this.subscription.add(
      this.paymentTypeService.updatePaymentType(paymenttype).subscribe({
        next: (result: any) => {
          alert('Payment Type updated successfully');
          this.spinner.hide();
          this.router.navigate(['/paymenttypes']);
        },
        error: (error: any) => {
          this.handleError(error);
        },
      })
    )
    
  }

  handleSubmit() {
    const paymenttype = this.paymentTypeForm.value as PaymentTypePayload;
    paymenttype.id = this.paymentType?.id;
    this.updatePaymentType(paymenttype);
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
