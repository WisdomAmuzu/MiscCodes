import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { DatePipe } from '@angular/common';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatStepperModule } from '@angular/material/stepper';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatTabsModule } from '@angular/material/tabs';
import { PaymentsService } from '../../services/payments/payments.service';
import {
  Payment,
  ReportsPayload,
  Reversal,
  ReversalPayload,
  User,
} from 'src/app/utils/types';
import { AgGridAngular } from 'ag-grid-angular'; // Angular Data Grid Component
import {
  ColDef,
  GridApi,
  GridOptions,
  FirstDataRenderedEvent,
} from 'ag-grid-community'; // Column Definition Type Interface
import { AuthService } from 'src/app/services/auth/auth.service';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { HttpErrorResponse } from '@angular/common/http';
import { ReversalsService } from 'src/app/services/reversals/reversals.service';
import { ActionButtonsComponent } from 'src/app/shared/action-buttons/action-buttons.component';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { PrintService } from 'src/app/services/print/print.service';
import { MatIconModule } from '@angular/material/icon';
import { Subscription } from 'rxjs';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatIconModule,
    MatCheckboxModule,
    MatStepperModule,
    MatDatepickerModule,
    MatNativeDateModule,
    AgGridAngular,
    NgxSpinnerModule,
    MatTabsModule,
  ],
  providers: [DatePipe],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css'],
})
export class ReportsComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  user?: User;
  frameworkComponents: any;
  public gridOptions: GridOptions;
  private gridApi!: GridApi;
  @ViewChild('paymentGrid') grid!: AgGridAngular;
  @ViewChild('reversalGrid') revGrid!: AgGridAngular;
  payments: Payment[] = [];
  reversals: Reversal[] = [];

  payShow = false; // Show Payment Modal
  confrimPayRetry = false; // Payment Retry Confirmation Modal
  showReversal = false; // Toggle the reversal comment and button

  revShow = false; // Show Reversal Modal
  confirmReversal = false; // Reversal Confirmation Modal
  confirmRevApproval = false; // Reversal Approval Confirmation Modal
  cancelRevApproval = false; // Reversal Cancellation Confirmation Modal
  refNo = '';
  payment?: any;
  reversal?: any;
  filter = '';

  activeTabIndex: number = 0;
  activeTabLabel: string = 'Payments';
  date = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

  dateForm = this.fb.group({
    start_date: [this.date, Validators.required],
    end_date: [this.date, Validators.required],
  });

  defaultColDef = {
    resizable: true,
  };

  skipList: unknown[] = ['bbresponse'];

  reversalForm = this.fb.group({
    payment: [{ value: '', disabled: true }, Validators.required],
    reason: ['', Validators.required],
  });

  colDefs: ColDef[] = [
    { headerName: 'Date', field: 'created_at' },
    { headerName: 'Teller', field: 'fullname' },
    { field: 'customer' },
    { field: 'amount', maxWidth: 100 },
    { headerName: 'Narration', field: 'description', maxWidth: 200 },
    { field: 'status', maxWidth: 100 },
    {
      headerName: 'Actions',
      cellRenderer: ActionButtonsComponent,
      cellRendererParams: {
        onClick: this.onButtonClick.bind(this),
        label: 'View Details',
      },
      maxWidth: 90,
    },
  ];

  revColDefs: ColDef[] = [
    { headerName: 'Date', field: 'created_at' },
    { headerName: 'Teller', field: 'fullname' },
    { field: 'reason' },
    { field: 'status' },
    {
      headerName: 'Actions',
      cellRenderer: ActionButtonsComponent,
      cellRendererParams: {
        onClick: this.onRevButtonClick.bind(this),
        label: 'View Details',
      },
    },
  ];

  constructor(
    private paymentService: PaymentsService,
    private reversalService: ReversalsService,
    private auth: AuthService,
    private spinner: NgxSpinnerService,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private printer: PrintService,
  ) {
    this.gridOptions = {
      // Define grid options here
    };
  }

  onGridReady(params: any): void {
    this.gridApi = params.api;
    // this.gridApi.sizeColumnsToFit();
  }

  onFirstDataRendered(params: FirstDataRenderedEvent) {
    params.api.expandAll();
  }

  ngOnInit(): void {
    this.user = this.auth.getUser();
  }

  ngOnDestroy(): void {
      this.subscription.unsubscribe()
  }

  onTabChange(event: MatTabChangeEvent) {
    this.activeTabIndex = event.index;
    this.activeTabLabel = event.tab.textLabel;
  }

  onButtonClick(params: any): void {
    // Can get reference number from params.rowData.referenceno
    this.refNo = params.rowData.referenceno;
    this.payment = params.rowData;
    if (params.button == 'view' && this.payment) {
      this.payShow = true;
    }
    if (params.button == 'print' && this.payment) {
      this.displayReceipt();
    }
  }

  displayReceipt() {
    this.navigateToReceiptUrl(this.refNo);
  }

  navigateToReceiptUrl(referenceno: string): void {
    const url = `${environment.receiptsUrl}/${referenceno}`;
    window.open(url, '_blank');
  }

  onRevButtonClick(params: any): void {
    // Can get reference number from params.rowData.referenceno
    this.refNo = params.rowData.referenceno;
    this.reversal = params.rowData;
    this.revShow = true;
  }

  onFilterChanged() {
    if (this.activeTabLabel == 'Payments') {
      this.grid.api.setGridOption(
        'quickFilterText',
        (document.getElementById('filter-text-box') as HTMLInputElement).value
      );
    }
    if (this.activeTabLabel == 'Reversals') {
      this.revGrid.api.setGridOption(
        'quickFilterText',
        (document.getElementById('filter-text-box') as HTMLInputElement).value
      );
    }
  }

  fetchPayments(payload: ReportsPayload) {
    this.spinner.show();
    this.subscription.add(
      this.paymentService.fetchPayments(payload).subscribe({
        next: (result: any) => {
          this.payments = result.payments;
          this.spinner.hide();
          if (result.payments.length == 0) {
            alert('No payments found for given date');
          }
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  fetchReversals(payload: ReportsPayload) {
    this.spinner.show();
    this.subscription.add(
      this.reversalService.fetchReversals(payload).subscribe({
        next: (result: any) => {
          this.reversals = result.reversals;
          this.spinner.hide();
          if (result.reversals.length == 0) {
            alert('No reversals found for given date');
          }
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error)
        },
      })
    )
    
  }

  handleSubmit() {
    const rawStartDate = this.dateForm?.get('start_date')?.value;
    const rawEndDate = this.dateForm?.get('end_date')?.value;

    const start_date = this.datePipe.transform(
      rawStartDate,
      'yyyy-MM-ddTHH:mm:ss'
    );
    const end_date = this.datePipe.transform(rawEndDate, 'yyyy-MM-ddTHH:mm:ss');

    const payload: ReportsPayload = {
      start_date: start_date!,
      end_date: end_date!,
    };
    if (this.activeTabLabel === 'Payments') {
      // const payload: ReportsPayload = this.dateForm.value as ReportsPayload
      this.fetchPayments(payload);
    }
    if (this.activeTabLabel === 'Reversals') {
      // const payload: ReportsPayload = this.dateForm.value as ReportsPayload
      this.fetchReversals(payload);
    }
  }

  handlePdfDownload($event: Event) {
    // event?.preventDefault();
    if (this.activeTabLabel == 'Payments') {
      this.downloadPaymentsPdf();
    }
    if (this.activeTabLabel == 'Reversals') {
      this.downloadReversalsPdf();
    }
  }

  handleExcelDownload($event: Event) {
    if (this.activeTabLabel == 'Payments') {
      this.downloadPaymentsExcel();
    }
    // if (this.activeTabLabel == 'Reversals') {
    //   this.downloadReversalsPdf();
    // }
  }

  downloadPaymentsPdf() {
    const rawStartDate = this.dateForm?.get('start_date')?.value;
    const rawEndDate = this.dateForm?.get('end_date')?.value;

    const start_date = this.datePipe.transform(rawStartDate, 'yyyy-MM-dd');
    const end_date = this.datePipe.transform(rawEndDate, 'yyyy-MM-dd');
    const branch = this.user?.branch;
    const payload = {
      start_date: start_date!,
      end_date: end_date!,
      branch: branch,
    };
    this.paymentService.downloadPdf(payload);
  }

  downloadPaymentsExcel() {
    const rawStartDate = this.dateForm?.get('start_date')?.value;
    const rawEndDate = this.dateForm?.get('end_date')?.value;

    const start_date = this.datePipe.transform(rawStartDate, 'yyyy-MM-dd');
    const end_date = this.datePipe.transform(rawEndDate, 'yyyy-MM-dd');
    const branch = this.user?.branch;
    const payload = {
      start_date: start_date!,
      end_date: end_date!,
      branch: branch,
    };
    this.paymentService.downloadExcel(payload);
  }

  downloadReversalsPdf() {
    const rawStartDate = this.dateForm?.get('start_date')?.value;
    const rawEndDate = this.dateForm?.get('end_date')?.value;

    const start_date = this.datePipe.transform(
      rawStartDate,
      'yyyy-MM-ddTHH:mm:ss'
    );
    const end_date = this.datePipe.transform(rawEndDate, 'yyyy-MM-ddTHH:mm:ss');
    const branch = this.user?.branch;
    const payload = {
      start_date: start_date!,
      end_date: end_date!,
      branch: branch,
    };
    this.reversalService.downloadPdf(payload);
  }

  // ! Teller methods
  // ? Payments

  showConfirmationReversal() {
    this.confirmReversal = true;
  }

  reversePayment(payload: ReversalPayload) {
    this.payShow = false;
    this.confirmReversal = false;
    this.spinner.show();
    this.subscription.add(
      this.reversalService.reversePayment(payload).subscribe({
        next: (result: any) => {
          this.spinner.hide();
          alert('Payment reversal initiation successtul');
          this.refresh();
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  submitReversal() {
    if (this.reversalForm.valid) {
      this.reversalForm.get('payment')?.enable();
      this.reversalForm.patchValue({
        payment: this.refNo,
      });

      const payload: ReversalPayload = this.reversalForm
        .value as ReversalPayload;
      this.reversePayment(payload);
    }
  }

  // ! -----------------------------------

  // ! Supervisor methods
  // ? Payments

  cancelPayment(referenceNo: string) {}

  submitPaymentRetry() {
    this.retryPayment(this.refNo);
  }

  showPaymentRetryConfirmation() {
    this.confrimPayRetry = true;
  }

  retryPayment(referenceNo: string) {
    this.revShow = false;
    this.confrimPayRetry = false;
    this.spinner.show();
    this.subscription.add(
      this.paymentService.retryPayment(referenceNo).subscribe({
        next: (result: any) => {
          this.spinner.hide();
          alert('Payment retried successsfully');
          this.refresh();
        },
        error: (error: any) => {
          this.handleError(error);
        },
      })
    )
    
  }
  // ? -----------------------------------

  // ? Reversal
  showConfirmationForApprovalRev() {
    this.confirmRevApproval = true;
  }

  showConfirmationCancellationRev() {
    this.cancelRevApproval = true;
  }

  approveReversal(referenceNo: string) {
    this.revShow = false;
    this.confirmRevApproval = false;
    this.spinner.show();
    this.subscription.add(
      this.reversalService.approveReversal(referenceNo).subscribe({
        next: (result: any) => {
          this.spinner.hide();
          alert('Reversal approved successfully');
          this.refresh();
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error)
        },
      })
      )
    
  }

  cancelReversal(referenceNo: string) {
    this.revShow = false;
    this.cancelRevApproval = false;
    this.spinner.show();
    this.subscription.add(
      this.reversalService.cancelReversal(referenceNo).subscribe({
        next: (result: any) => {
          this.spinner.hide();
          alert('Reversal cancelled successfully');
          this.refresh();
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error)
        },
      })
    )
    
  }

  submitReversalApproval() {
    this.approveReversal(this.refNo);
  }

  submitReversalCancellation() {
    this.cancelReversal(this.refNo);
  }
  // ? -----------------------------------

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.refresh();
      this.auth.loginSignal.set(false);
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}