import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatStepperModule } from '@angular/material/stepper';
import { ChargesService } from '../../services/charges/charges.service';
import { PaymentsService } from '../../services/payments/payments.service';
import {
  Charge,
  Institution,
  Payment,
  PaymentPayload,
  PaymentPostData,
  PaymentType,
  User,
} from 'src/app/utils/types';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth/auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { InstitutionsService } from 'src/app/services/institutions/institutions.service';
import { PaymenttypeService } from 'src/app/services/paymenttype/paymenttype.service';
import { MatStepper } from '@angular/material/stepper';
import { environment } from 'src/environments/environment';
import { Subscription } from 'rxjs';
import { GlobalErrorHandlerService } from 'src/app/services/global-error-handler/global-error-handler.service';

@Component({
  selector: 'app-pay',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatSidenavModule,
    MatFormFieldModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatCheckboxModule,
    MatDividerModule,
    MatStepperModule,
    // MatDialogModule,
    NgxSpinnerModule,
  ],
  templateUrl: './pay.component.html',
  styleUrls: ['./pay.component.css'],
})
export class PayComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  smSpinner = 'sp1';
  lgSpinner = 'sp2';
  isLoading = true;
  show = false; // Should be false
  errorMsg = '';
  successMsg = '';
  payments: any = [];
  payment?: Payment;
  amountToPay = 0;
  charges: Charge[] = [];
  selectedCharges: number[] = [];
  chargesIds: number[] = [];
  institutions: Institution[] = []; //
  paymentTypes: PaymentType[] = [];
  paymentMethods: string[] = ['CASH'];
  user?: User;
  // For display on the summary screen
  institution?: Institution;
  description?: string;

  institutionForm = this.fb.group({
    institution: [0, [Validators.required]],
  });

  paymentTypeForm = this.fb.group({
    paymenttype: ['', [Validators.required]],
  });

  paymentMethodForm = this.fb.group({
    paymentmethod: ['CASH', [Validators.required]],
  });

  paymentForm = this.fb.group({
    passportno: ['', [Validators.required]], // Assuming passport numbers are alphanumeric
    description: [''],
    amount: [
      this.amountToPay,
      [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?$/)],
    ], // Numeric with up to 2 decimal places
    customerphoneno: [
      '',
      [Validators.required, Validators.minLength(10), Validators.maxLength(10)],
    ],
    customeremail: ['', [Validators.email]],
    surname: ['', [Validators.required]],
    othernames: ['', [Validators.required]],
  });

  constructor(
    private fb: FormBuilder,
    private chargesService: ChargesService,
    private paymentService: PaymentsService,
    private spinner: NgxSpinnerService,
    private auth: AuthService,
    private institutionService: InstitutionsService,
    private paymentTypeService: PaymenttypeService,
    private errorHandler: GlobalErrorHandlerService,
  ) {}

  ngOnInit(): void {
    this.spinner.show(this.smSpinner);
    Promise.all([this.fetchInstitutions()]).then(() => {
      this.user = this.auth.getUser();
      this.spinner.hide(this.smSpinner);
      this.institutionForm.patchValue({
        institution: this.institutions[0]?.id!,
      });
      this.paymentMethodForm.patchValue({
        paymentmethod: this.paymentMethods[0],
      });
    });
  }

  ngOnDestroy(): void {
      this.subscription.unsubscribe()
  }

  onStepChange(event: any) {
    if (event.selectedIndex === 1) {
      this.fetchPaymentTypes(
        '' + this.institutionForm.get('institution')?.value!
      );
    }
    if (event.selectedIndex == 2) {
      this.fetchCharges(this.paymentTypeForm.get('paymenttype')?.value!);
    }
    if (event.selectedIndex == 4) {
      this.institution = this.institutions.find(
        (el) => el.id === this.institutionForm.get('institution')?.value
      );
      const paymentType = this.paymentTypes.find(
        (el) => el.id === this.paymentTypeForm.get('paymenttype')?.value
      );
      this.description = paymentType?.name;
    }
  }

  goToFirstStep(stepper: MatStepper) {
    stepper.reset();
  }

  fetchInstitutions() {
    this.subscription.add(
      this.institutionService.fetchInstitutions().subscribe({
        next: (result) => {
          this.institutions = result.institutions;
          this.institutionForm.patchValue({
            institution: this.institutions[0].id,
          });
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  fetchPaymentTypes(institution: string) {
    this.subscription.add(
      this.paymentTypeService.fetchPaymentTypes(institution).subscribe({
        next: (result: any) => {
          this.paymentTypes = result.paymenttypes;
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
  }

  calculateAmount(event: any, id: number) {
    if (event.checked) {
      // If the checkbox is checked and the ID is not already in the array, add it
      if (!this.chargesIds.includes(id)) {
        this.chargesIds.push(id);
      }
    } else {
      // If the checkbox is unchecked, remove the ID from the array
      const index = this.chargesIds.indexOf(id);
      if (index > -1) {
        this.chargesIds.splice(index, 1);
      }
    }

    // Recalculate the total charges
    this.fetchTotalCharge();
  }

  // ! Get calculated charges from backend
  fetchCharges(paymentType: string) {
    // this.isLoading = true
    this.spinner.show();
    this.subscription.add(
      this.chargesService.getCharges(paymentType).subscribe({
        next: (result: any) => {
          this.charges = result.charges;
          this.spinner.hide();
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  fetchTotalCharge() {
    this.spinner.show();
    this.subscription.add(
      this.chargesService.getCalculatedCharges(this.chargesIds).subscribe({
        next: (result: any) => {
          this.amountToPay = result.total;
          this.spinner.hide();
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  handleSubmit() {
    if (this.paymentForm.valid) {
      this.paymentForm.get('institution')?.enable();
      this.paymentForm.get('description')?.enable();
      const payload: PaymentPayload = {
        amount: this.amountToPay, // ! Actual amount to post
        // amount: 1, // ! For Testing
        description: '',
        passportno: this.paymentForm.get('passportno')?.value!,
        customerphoneno: this.paymentForm.get('customerphoneno')?.value!,
        institution: this.institutionForm.get('institution')?.value!,
        paymenttype: this.paymentTypeForm.get('paymenttype')?.value!,
        paymentmethod: this.paymentMethodForm.get('paymentmethod')?.value!,
        surname: this.paymentForm.get('surname')?.value!,
        othernames: this.paymentForm.get('othernames')?.value!,
        customeremail: this.paymentForm.get('customeremail')?.value!,
        teller: this.user?.username!,
      };
      // Find the chosen payment id and set the description value to the payment type name
      const paymentType = this.paymentTypes.find(
        (el) => el.id === +payload.paymenttype
      );
      payload.description = paymentType?.name!;

      const paymentPayload = {
        payment: payload,
        charges: this.chargesIds,
      };
      this.savePayment(paymentPayload);
      // this.resetForm()
    }
  }

  savePayment(paymentPayload: PaymentPostData) {
    this.show = false;
    this.spinner.show();
    this.subscription.add(
      this.paymentService.savePayment(paymentPayload).subscribe({
        next: (result: any) => {
          this.payment = result.payment;
          // this.successMsg = result.message;
          alert(result.message);
          this.spinner.hide();
          this.navigateToReceiptUrl();
          this.refresh();
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  navigateToReceiptUrl(): void {
    const url = `${environment.receiptsUrl}/${this.payment?.referenceno}`;
    window.open(url, '_blank');
  }

  resetForm() {
    this.paymentForm.reset();
  }

  showModal() {
    this.show = true;
  }

  hideModal() {
    this.show = false;
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    this.errorHandler.handleError(error);
    if (error.status == 401) {
      alert('Session expired');
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
      this.refresh();
    }
  }
}
