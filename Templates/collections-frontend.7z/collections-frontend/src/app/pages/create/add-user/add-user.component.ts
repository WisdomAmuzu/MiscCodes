import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormControl,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { Branch, User, UserPayload } from 'src/app/utils/types';
import { MatSelectModule } from '@angular/material/select';
import { BranchesService } from 'src/app/services/branches/branches.service';
import { AuthService } from 'src/app/services/auth/auth.service';
import { InstitutionsService } from 'src/app/services/institutions/institutions.service';
import { UsersService } from 'src/app/services/users/users.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-user',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    NgxSpinnerModule,
  ],
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css'],
})
export class AddUserComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  user?: User;
  branches?: Branch[];
  usergroups = environment.userRoles;
  successMsg = '';
  errorMsg = '';
  userForm = this.fb.group({
    username: ['', [Validators.required]],
    usergroup: ['', [Validators.required]],
    fullname: ['', [Validators.required]],
    branch: [''],
    initials: ['', [Validators.required]],
  });

  constructor(
    private auth: AuthService,
    private fb: FormBuilder,
    private branchService: BranchesService,
    private userService: UsersService,
    private spinner: NgxSpinnerService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.user = this.auth.getUser();
    Promise.all([this.fetchBranches()]).then();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
  }

  handleSubmit() {
    const payload = this.userForm.value as UserPayload;

    this.saveUser(payload);
  }

  fetchBranches() {
    this.subscription.add(
      this.branchService.fetchBranches().subscribe({
        next: (result: any) => {
          this.branches = result.branches;
        },
        error: (error) => {
          this.handleError(error);
        },
      })
    )
    
  }

  saveUser(user: UserPayload) {
    this.spinner.show();
    this.subscription.add(
      this.userService.saveUser(user).subscribe({
        next: (result: any) => {
          // this.successMsg = result.message;
          this.spinner.hide();
          alert(result.message);
          this.router.navigate(['/users']);
        },
        error: (error: HttpErrorResponse) => {
          // this.errorMsg = result.message
          this.handleError(error);
        },
      })
    )
    
  }

  integerOrNullValidator(control: FormControl): { [key: string]: boolean } | null {
    if (control.value === null || control.value === undefined) {
      return null; // If value is null or undefined, it's valid
    }
    return Number.isInteger(control.value) ? null : { notInteger: true };
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
