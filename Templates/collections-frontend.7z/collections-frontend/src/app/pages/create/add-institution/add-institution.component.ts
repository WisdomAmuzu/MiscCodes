import { CommonModule } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Institution } from '../../../utils/types';
import { InstitutionsService } from 'src/app/services/institutions/institutions.service';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-institution',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    NgxSpinnerModule,
  ],
  templateUrl: './add-institution.component.html',
  styleUrls: ['./add-institution.component.css'],
})
export class AddInstitutionComponent implements OnDestroy {
  private subscription: Subscription = new Subscription();

  successMsg = '';
  errorMsg = '';
  institutionForm = this.fb.group({
    name: ['', [Validators.required]],
  });

  constructor(
    private fb: FormBuilder,
    private institutionsService: InstitutionsService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private auth: AuthService
  ) {}

  ngOnDestroy(): void {
      this.subscription.unsubscribe()
  }

  handleSubmit() {
    const institution = this.institutionForm.value as Institution;
    this.saveInstitution(institution);
  }

  saveInstitution(institution: Institution) {
    this.spinner.show();
    this.subscription.add(
      this.institutionsService.saveInstitution(institution).subscribe({
        next: (result: any) => {
          // this.successMsg = result.message
          alert(result.message);
          this.spinner.hide();
          this.router.navigate(['/institutions']);
          // this.resetForm()
        },
        error: (error: HttpErrorResponse) => {
          // this.errorMsg = result.message
          this.handleError(error);
        },
      })
    )
    
  }

  resetForm() {
    this.institutionForm.patchValue({
      name: '',
    });
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
