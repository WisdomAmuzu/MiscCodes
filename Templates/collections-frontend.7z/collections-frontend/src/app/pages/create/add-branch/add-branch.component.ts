import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { BranchesService } from 'src/app/services/branches/branches.service';
import { Branch, Institution, User } from 'src/app/utils/types';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-branch',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    NgxSpinnerModule,
    MatSelectModule,
  ],
  templateUrl: './add-branch.component.html',
  styleUrls: ['./add-branch.component.css'],
})
export class AddBranchComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  user?: User;
  successMsg = '';
  errorMsg = '';
  institutions?: Institution[];
  branchForm = this.fb.group({
    name: ['', Validators.required],
    branchcode: [''],
    suspaccno: ['', Validators.required],
    // ipaddress: [''],
  });

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private branchesService: BranchesService,
    private spinner: NgxSpinnerService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    Promise.all([]);
  }

  ngOnDestroy(): void {
      this.subscription.unsubscribe()
  }

  handleSubmit() {
    const branch = this.branchForm.value as Branch;
    this.saveBranch(branch);
  }

  saveBranch(branch: Branch) {
    this.spinner.show();
    this.subscription.add(
      this.branchesService.saveBranch(branch).subscribe({
        next: (result: any) => {
          // this.successMsg = result.message
          alert(result.message);
          this.router.navigate(['/branches']);
          this.spinner.hide();
        },
        error: (error: HttpErrorResponse) => {
          // this.errorMsg = result.message
          this.handleError(error);
        },
      })
    )
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
