import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPaymenttypeComponent } from './add-paymenttype.component';

describe('AddPaymenttypeComponent', () => {
  let component: AddPaymenttypeComponent;
  let fixture: ComponentFixture<AddPaymenttypeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AddPaymenttypeComponent]
    });
    fixture = TestBed.createComponent(AddPaymenttypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
