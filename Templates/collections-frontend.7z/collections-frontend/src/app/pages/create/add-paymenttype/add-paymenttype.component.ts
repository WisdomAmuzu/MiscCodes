import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { BranchesService } from 'src/app/services/branches/branches.service';
import { InstitutionsService } from 'src/app/services/institutions/institutions.service';
import {
  Branch,
  Institution,
  PaymentType,
  PaymentTypePayload,
  User,
} from 'src/app/utils/types';
import { AuthService } from 'src/app/services/auth/auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { PaymenttypeService } from 'src/app/services/paymenttype/paymenttype.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-paymenttype',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    NgxSpinnerModule,
    MatSelectModule,
  ],
  templateUrl: './add-paymenttype.component.html',
  styleUrls: ['./add-paymenttype.component.css'],
})
export class AddPaymenttypeComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  user?: User;
  successMsg = '';
  errorMsg = '';
  institutions: Institution[] = [];

  paymentTypeForm = this.fb.group({
    name: ['', Validators.required],
    institution: ['', Validators.required],
    accountno: ['', Validators.required],
  });

  constructor(
    private auth: AuthService,
    private router: Router,
    private fb: FormBuilder,
    private branchesService: BranchesService,
    private institutionsService: InstitutionsService,
    private paymentTypeService: PaymenttypeService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit(): void {
    Promise.all([this.fetchInstitutions()]);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
  }

  fetchInstitutions() {
    this.subscription.add(
      this.institutionsService.fetchInstitutionsAdmin().subscribe({
        next: (result: any) => {
          this.institutions = result.institutions;
        },
        error: (error: HttpErrorResponse) => {
          // this.errorMsg = error.message
          this.handleError(error);
        },
      })
    )
    
  }

  handleSubmit() {
    const payload = this.paymentTypeForm.value as PaymentTypePayload;
    payload.institution = 1;
    this.savePaymentType(payload);
  }

  savePaymentType(paymentType: PaymentTypePayload) {
    this.spinner.show();
    this.subscription.add(
      this.paymentTypeService.savePaymentType(paymentType).subscribe({
        next: (result: any) => {
          // this.successMsg = result.message
          this.spinner.hide();
          alert(result.message);
          this.router.navigate(['/paymenttypes']);
          // this.errorMsg = ''
        },
        error: (error: HttpErrorResponse) => {
          // this.errorMsg = error.message
          this.handleError(error);
          // this.successMsg = ''
        },
      })
    ) 
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
