import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { Router } from '@angular/router';
import { ChargesService } from 'src/app/services/charges/charges.service';
import { InstitutionsService } from 'src/app/services/institutions/institutions.service';
import { PaymenttypeService } from 'src/app/services/paymenttype/paymenttype.service';
import {
  Charge,
  ChargePayload,
  Institution,
  PaymentType,
} from 'src/app/utils/types';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-charge',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    NgxSpinnerModule,
  ],
  templateUrl: './add-charge.component.html',
  styleUrls: ['./add-charge.component.css'],
})
export class AddChargeComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  successMsg = '';
  errorMsg = '';
  institutions: Institution[] = [];
  paymenttypes: PaymentType[] = [];
  chargeForm = this.fb.group({
    name: ['', Validators.required],
    paymenttype: ['', Validators.required],
    institution: ['', Validators.required],
    amount: [0, Validators.required],
    // mandatory: ['', Validators.required],
  });

  constructor(
    private fb: FormBuilder,
    private institutionService: InstitutionsService,
    private paymentTypeService: PaymenttypeService,
    private chargeService: ChargesService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    Promise.all([this.fetchInstitutions()]);
    this.chargeForm.get('institution')?.valueChanges.subscribe((_) => {
      this.onSelectChange();
    });
  }

  ngOnDestroy(): void {
      this.subscription.unsubscribe()
  }

  onSelectChange(): void {
    this.fetchPaymentTypes();
  }

  handleSubmit() {
    const payload = this.chargeForm.value as ChargePayload;
    // payload.institution = 1
    // payload.paymenttype = 1
    this.saveCharge(payload);
  }

  fetchInstitutions() {
    this.subscription.add(
      this.institutionService.fetchInstitutionsAdmin().subscribe({
        next: (result: any) => {
          this.institutions = result.institutions;
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  fetchPaymentTypes() {
    this.subscription.add(
      this.paymentTypeService
      .fetchPaymentTypes(this.chargeForm.get('institution')?.value!)
      .subscribe({
        next: (result: any) => {
          this.paymenttypes = result.paymenttypes;
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
    
  }

  saveCharge(charge: ChargePayload) {
    this.spinner.show();
    this.subscription.add(
      this.chargeService.saveCharge(charge).subscribe({
        next: (result: any) => {
          // this.successMsg = result.message
          this.spinner.hide();
          alert(result.message);
          this.router.navigate(['/charges']);
        },
        error: (error: HttpErrorResponse) => {
          // this.errorMsg = error.message
          this.handleError(error);
        },
      })
    )
    
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
