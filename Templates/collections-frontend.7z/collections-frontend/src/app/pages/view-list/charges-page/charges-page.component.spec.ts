import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargesPageComponent } from './charges-page.component';

describe('ChargesPageComponent', () => {
  let component: ChargesPageComponent;
  let fixture: ComponentFixture<ChargesPageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ChargesPageComponent]
    });
    fixture = TestBed.createComponent(ChargesPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
