import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ChargesService } from '../../../services/charges/charges.service';
import { Charge } from 'src/app/utils/types';
import { Router, RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-charges-page',
  standalone: true,
  imports: [CommonModule, MatIconModule, NgxSpinnerModule, RouterModule],
  templateUrl: './charges-page.component.html',
  styleUrls: ['./charges-page.component.css'],
})
export class ChargesPageComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  charges: Charge[] = [];
  constructor(
    private chargesService: ChargesService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    Promise.all([this.fetchCharges()]);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
  }

  fetchCharges() {
    this.spinner.show()

    this.subscription.add(
      this.chargesService.fetchChargesAdmin().subscribe({
        next: (result: any) => {
          this.charges = result.charges;
          this.spinner.hide();

        },
        error: (error: any) => {
          this.handleError(error);
        },
      })
    )
  }

  goToEdit(id: number) {
    this.router.navigate([`/charges/${id}/update`]);
  }

  deleteCharge(id: number) {
    this.spinner.show()

    this.subscription.add(
      this.chargesService.deleteCharge(id).subscribe({
        next: (result: any) => {
          alert(result.message)
          this.fetchCharges()
          this.spinner.hide();

        },
        error: (error) => {
          this.handleError(error)
        }
      })
    )
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
