import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { UsersService } from '../../../services/users/users.service';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { HttpErrorResponse } from '@angular/common/http';
import { User, UserAdmin } from 'src/app/utils/types';
import { Router, RouterModule } from '@angular/router';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-users-page',
  standalone: true,
  imports: [
    CommonModule,
    MatListModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    NgxSpinnerModule,
    RouterModule,
  ],
  templateUrl: './users-page.component.html',
  styleUrls: ['./users-page.component.css'],
})
export class UsersPageComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  users: UserAdmin[] = [];
  constructor(
    private userService: UsersService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    Promise.all([this.getAllUsers()]).then();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
  }

  getAllUsers() {
    this.spinner.show();

    this.subscription.add(
      this.userService.fetchUsers().subscribe({
        next: (result: any) => {
          this.users = result.users;
        this.spinner.hide();
        },
        error: (error: HttpErrorResponse) => {
          // this.errorMsg = result.message
          this.handleError(error);
        },
      })
    )
  }

  gotToEdit(id: number) {
    this.router.navigate([`/users/${id}/update`]);
  }

  deleteUser(id: number) {
    this.spinner.show();
    
    this.subscription.add(this.userService.deleteUser(id).subscribe({
      next: (result: any) => {
        alert(result.message)
        this.getAllUsers()
        this.spinner.hide();

      },
      error: (error) => {
        this.handleError(error)
      }
    })
  )
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
