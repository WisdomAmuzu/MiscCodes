import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { Institution } from 'src/app/utils/types';
import { InstitutionsService } from 'src/app/services/institutions/institutions.service';
import { MatIconModule } from '@angular/material/icon';
import { HttpErrorResponse } from '@angular/common/http';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  standalone: true,
  imports: [CommonModule, MatIconModule, NgxSpinnerModule, RouterModule],
  selector: 'app-institutions',
  templateUrl: './institutions.component.html',
  styleUrls: ['./institutions.component.css'],
})
export class InstitutionsComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  institutions?: Institution[];

  constructor(
    private institutionService: InstitutionsService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    Promise.all([this.fetchAllInstitutions()]);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
  }

  fetchAllInstitutions() {
    this.spinner.show();

    this.subscription.add(
      this.institutionService.fetchInstitutionsAdmin().subscribe({
        next: (result: any) => {
          this.institutions = result.institutions;
          this.spinner.hide();

        },
        error: (error: HttpErrorResponse) => {
          // this.errorMsg = result.message
          this.handleError(error);
        },
      })
    )
  }

  goToEdit(id: number) {
    this.router.navigate([`institutions/${id}/update`]);
  }

  deleteInstitution(id: number) {
    this.spinner.show();

    this.subscription.add(
      this.institutionService.deleteInstitution(id).subscribe({
        next: (result: any) => {
          alert(result.message)
          this.fetchAllInstitutions()
          this.spinner.hide();

        },
        error: (error) => {
          this.handleError(error)
        }
      })
    )
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
