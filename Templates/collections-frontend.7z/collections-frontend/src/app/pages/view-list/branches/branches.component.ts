import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { Router, RouterModule } from '@angular/router';
import { BranchesService } from 'src/app/services/branches/branches.service';
import { Branch } from 'src/app/utils/types';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-branches',
  standalone: true,
  imports: [CommonModule, MatIconModule, NgxSpinnerModule, RouterModule],
  templateUrl: './branches.component.html',
  styleUrls: ['./branches.component.css'],
})
export class BranchesComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  branches: Branch[] = [];

  constructor(
    private branchService: BranchesService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    Promise.all([this.fetchBranches()]);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
  }

  fetchBranches() {
    this.spinner.show();
    this.subscription.add(
      this.branchService.fetchBranches().subscribe({
        next: (result: any) => {
          this.branches = result.branches;
          this.spinner.hide();
        },
        error: (error: HttpErrorResponse) => {
          this.handleError(error);
        },
      })
    )
  }

  goToEdit(id: number) {
    this.router.navigate([`/branches/${id}/update`]);
  }

  deleteBranch(id: number) {
    this.spinner.show();

    this.subscription.add(
      this.branchService.deleteBranch(id).subscribe({
        next: (result: any) => {
          alert(result.message)
          this.fetchBranches()
          this.spinner.hide();

        },
        error: (error) => {
          this.handleError(error)
        }
      })
    )
  }

  refresh(): void {
    window.location.reload();
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.auth.loginSignal.set(false);
      // this.router.navigate(['/login'])
      this.refresh();
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }
}
