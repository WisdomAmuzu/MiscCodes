import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardService } from 'src/app/services/dashboard/dashboard.service';
import { DashboardData } from 'src/app/utils/types';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from 'src/app/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
    imports: [CommonModule, NgxSpinnerModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  data?: DashboardData;
  constructor (
    private dashboardService: DashboardService,
    private spinner: NgxSpinnerService,
    private auth: AuthService,
  ) {}

  ngOnInit(): void {
    Promise.all([this.getDashbordCounts()])
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe()
  }

  getDashbordCounts() {
    this.subscription.add(
      this.dashboardService.getDashboardCounts().subscribe({
        next: (result) => {
          this.data = {
            payments: result.payments,
            reversals: result.reversals,
          }
        },
        error: (error) => {
          this.handleError(error)
        }
      })
    )
      
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide();
    if (error.status == 401) {
      alert('Session expired');
      // this.errorMsg = error.error.message
      this.auth.clearSessionStorage();
      this.refresh();
      this.auth.loginSignal.set(false);
    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource");
    }
    if (error.status == 500) {
      alert(error.error.message);
    }
  }

  refresh(): void {
    window.location.reload();
  }
}
