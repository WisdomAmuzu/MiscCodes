import { ICellRendererAngularComp } from '@ag-grid-community/angular';
import { ICellRendererParams } from '@ag-grid-community/core';
import { Component, EventEmitter, Output } from '@angular/core';import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-action-buttons',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './action-buttons.component.html',
  styleUrls: ['./action-buttons.component.css']
})
export class ActionButtonsComponent implements ICellRendererAngularComp {
  @Output() viewClick = new EventEmitter<any>();
  params: any;
  label?: string;

  agInit(params: ICellRendererParams): void {
    this.params = params;
    this.label = this.params.label || null;
  }
  refresh(params: ICellRendererParams) {
    return true;
  }

  onClick($event: any) {
    if (this.params.onClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        button: 'view',
        rowData: this.params.node.data
        // ...something
      }
      this.params.onClick(params);

    }
  }

  onPrintClick($event: any) {
    if (this.params.onClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        button: 'print',
        rowData: this.params.node.data
        // ...something
      }
      this.params.onClick(params);

    }
    
  }


}
