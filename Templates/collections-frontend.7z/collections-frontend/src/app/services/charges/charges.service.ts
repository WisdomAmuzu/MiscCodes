import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, tap, throwError } from 'rxjs';
import { Charge, ChargePayload } from 'src/app/utils/types';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root',
})
export class ChargesService {
  private apiUrl = environment.apiUrl;
  private url = `${this.apiUrl}/charges`;

  constructor(private http: HttpClient, private auth: AuthService) {}

  setHeaders() {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
  }

  fetchChargesAdmin() {
    const headers = this.setHeaders();

    return this.http.get(this.url, { headers }).pipe(tap());
  }

  fetchCharge(id: number) {
    const headers = this.setHeaders();

    return this.http.get(`${this.url}/${id}`, { headers }).pipe(tap());
  }

  getCharges(paymentType: string): Observable<Charge[]> {
    const headers = this.setHeaders();

    return this.http
      .get<Charge[]>(`${this.url}/list/${paymentType}`, { headers })
      .pipe(
        tap(),
        catchError((error) => this.handleError(error))
      );
  }

  getCalculatedCharges(ids: number[]): Observable<{ charge: number }> {
    const headers = this.setHeaders();

    return this.http
      .post<{ charge: number }>(
        `${this.url}/calculate-total`,
        { ids },
        { headers }
      )
      .pipe(
        tap(),
        catchError((error) => this.handleError(error))
      );
  }

  saveCharge(charge: ChargePayload) {
    const headers = this.setHeaders();

    return this.http.post(this.url, charge, { headers }).pipe(tap());
  }

  updateCharge(charge: ChargePayload) {
    const headers = this.setHeaders();

    return this.http
      .patch(`${this.url}/${charge.id}`, charge, { headers })
      .pipe(
        tap(),
        catchError((error) => this.handleError(error))
      );
  }

  deleteCharge(id: number) {
    const headers = this.setHeaders();

    return this.http.delete(`${this.url}/${id}`, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  handleError(error: HttpErrorResponse): Observable<any> {
    return throwError(() => error);
  }
}
