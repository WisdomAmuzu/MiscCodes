import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class PrintService {
  constructor() {}

  printReceipt(content: string) {
    const printWindow = window.open('', '', 'height=600;width=800');
  }

  navigateToReceiptUrl(referenceno: string): void {
    const url = environment.receiptsUrl;
    window.open(url, '_blank')
  }
}
