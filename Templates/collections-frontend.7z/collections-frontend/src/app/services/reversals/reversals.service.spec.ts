import { TestBed } from '@angular/core/testing';

import { ReversalsService } from './reversals.service';

describe('ReversalsService', () => {
  let service: ReversalsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReversalsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
