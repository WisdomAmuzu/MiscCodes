import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { tap } from 'rxjs';
import {
  ReportsPayload,
  ReversalPayload,
} from 'src/app/utils/types';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth/auth.service';
import { map } from 'rxjs/operators';
import { saveAs } from 'file-saver';

@Injectable({
  providedIn: 'root',
})
export class ReversalsService {
  private apiUrl = environment.apiUrl;
  private url = `${this.apiUrl}/reversals`;

  constructor(private http: HttpClient, private auth: AuthService) {}

  setHeaders() {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
  }

  public fetchReversals(payload: ReportsPayload) {
    const headers = this.setHeaders();
    let params: any = {
      start_date: payload.start_date,
      end_date: payload.end_date,
    };

    if (payload.branch) {
      params.branch = payload.branch;
    }

    return this.http
      .get(`${this.url}/list`, { headers, params })
      .pipe(tap());
  }

  public fetchReversalsAdmin(payload: ReportsPayload) {
    const headers = this.setHeaders();
    let params: any = {
      start_date: payload.start_date,
      end_date: payload.end_date,
      branch: payload.branch,
    };

    return this.http
      .get(this.url, { headers, params })
      .pipe(tap());
  }

  public reversePayment(payload: ReversalPayload) {
    const headers = this.setHeaders();

    return this.http
      .post(`${this.url}/reverse`, payload, { headers })
      .pipe(tap());
  }

  public approveReversal(referenceNo: string) {
    const headers = this.setHeaders();

    return this.http
      .get(`${this.url}/${referenceNo}/approve-reversal`, { headers })
      .pipe(tap());
  }

  public cancelReversal(referenceNo: string) {
    const headers = this.setHeaders();

    return this.http
      .get(`${this.url}/${referenceNo}/cancel-reversal`, { headers })
      .pipe(tap());
  }

  getExcel(payload: ReportsPayload) {
    const headers = this.setHeaders();
    let params: any = {
      start_date: payload.start_date,
      end_date: payload.end_date,
      branch: payload.branch,
      type: 'excel',
    };

    return this.http
      .get(`${this.url}/export`, { headers, params, responseType: 'blob' })
      .pipe(
        tap(),
        map((res: Blob) => {
          return res;
        })
      );
  }

  downloadExcel(payload: ReportsPayload) {
    this.getExcel(payload).subscribe((excelBlob: Blob) => {
      const fileName = `Reversals_Report_${payload.start_date}-${payload.end_date}.xlsx`;
      saveAs(excelBlob, fileName);
    });
  }

  getPdf(payload: ReportsPayload) {
    const headers = this.setHeaders();
    let params: any = {
      start_date: payload.start_date,
      end_date: payload.end_date,
      branch: payload.branch,
      type: 'pdf',
    };

    return this.http
      .get(`${this.url}/export`, { headers, params, responseType: 'blob' })
      .pipe(
        tap(),
        map((res: Blob) => {
          return res;
        })
      );
  }

  downloadPdf(payload: ReportsPayload) {
    this.getPdf(payload).subscribe((pdfBlob: Blob) => {
      const fileName = `Reversals_Report_${payload.start_date}-${payload.end_date}.pdf`;
      saveAs(pdfBlob, fileName);
    });
  }

  exportReversals(payload: ReportsPayload, branch?: string) {
    let url = `${environment.apiUrl}/export-reversals?start_date=${payload.start_date}&end_date=${payload.end_date}`;
    if (branch) {
      url = url + `&branch=${branch}`;
    }
    window.open(url, '_blank');
  }
}
