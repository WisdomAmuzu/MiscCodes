import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import {
  Payment,
  PaymentPostData,
  PaymentSuccessResonse,
  ReportsPayload,
  ReversalPayload,
} from 'src/app/utils/types';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth/auth.service';
import { User } from 'src/app/utils/types';
import { map } from 'rxjs/operators';
import { saveAs } from 'file-saver';

@Injectable({
  providedIn: 'root',
})
export class PaymentsService {
  private apiUrl = environment.apiUrl;
  private url = `${this.apiUrl}/payments`;

  constructor(private http: HttpClient, private auth: AuthService) {}

  setHeaders() {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
  }

  public fetchPayments(payload: ReportsPayload): Observable<Payment[] | null> {
    const headers = this.setHeaders();
    let params: any = {
      start_date: payload.start_date,
      end_date: payload.end_date,
    };

    if (payload.branch !== undefined) {
      params.branch = payload.branch;
    }
    return this.http
      .get<Payment[]>(`${this.url}/list`, { headers, params })
      .pipe(tap());
  }

  public fetchPaymentsAdmin(
    payload: ReportsPayload
  ): Observable<Payment[] | null> {
    const headers = this.setHeaders();
    let params: any = {
      start_date: payload.start_date,
      end_date: payload.end_date,
      branch: payload.branch,
    };

    return this.http
      .get<Payment[]>(this.url, { headers, params })
      .pipe(tap());
  }

  public savePayment(
    paymentPayload: PaymentPostData
  ): Observable<PaymentSuccessResonse> {
    const headers = this.setHeaders();

    const payment = paymentPayload;
    return this.http
      .post<PaymentSuccessResonse>(`${this.url}/process`, payment, { headers })
      .pipe(tap());
  }

  public retryPayment(referenceno: string) {
    const headers = this.setHeaders();

    return this.http
      .get(`${this.url}/${referenceno}/retry`, { headers })
      .pipe(tap());
  }

  downloadReport(payload: ReportsPayload, type: string) {
    const headers = this.setHeaders();
    let params: any = {
      start_date: payload.start_date,
      end_date: payload.end_date,
      branch: payload.branch,
      type: type,
    };

    return this.http
      .get(`${this.url}/export`, {
        headers,
        params,
        responseType: 'blob' as 'json',
      })
      .pipe(tap());
  }

  getExcel(payload: ReportsPayload) {
    const headers = this.setHeaders();
    let params: any = {
      start_date: payload.start_date,
      end_date: payload.end_date,
      branch: payload.branch,
      type: 'excel',
    };

    return this.http
      .get(`${this.url}/export`, { headers, params, responseType: 'blob' })
      .pipe(
        tap(),
        map((res: Blob) => {
          return res;
        })
      );
  }

  downloadExcel(payload: ReportsPayload) {
    this.getExcel(payload).subscribe((excelBlob: Blob) => {
      const fileName = `Payments_Report_${payload.start_date}-${payload.end_date}.xlsx`;
      saveAs(excelBlob, fileName);
    });
  }

  getPdf(payload: ReportsPayload) {
    const headers = this.setHeaders();
    let params: any = {
      start_date: payload.start_date,
      end_date: payload.end_date,
      branch: payload.branch,
      type: 'pdf',
    };

    return this.http
      .get(`${this.url}/export`, { headers, params, responseType: 'blob' })
      .pipe(
        tap(),
        map((res: Blob) => {
          return res;
        })
      );
  }

  downloadPdf(payload: ReportsPayload) {
    this.getPdf(payload).subscribe((pdfBlob: Blob) => {
      const fileName = `Payments_Report_${payload.start_date}-${payload.end_date}.pdf`;
      saveAs(pdfBlob, fileName);
    });
  }

  exportPayments(payload: ReportsPayload, branch?: number) {
    let url = `${environment.apiUrl}/export-payments?start_date=${payload.start_date}&end_date=${payload.end_date}&branch=${payload.branch}`;
    if (branch) {
      url = url + `&branch=${branch}`;
    }
    window.open(url, '_blank');
  }
}
