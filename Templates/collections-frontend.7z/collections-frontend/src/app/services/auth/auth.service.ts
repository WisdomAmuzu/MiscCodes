import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable, Signal, signal } from '@angular/core';
// import { Router } from '@angular/router';
import { Observable, catchError, tap } from 'rxjs';
import { LoginPayload, LoginSuccResonse, User } from 'src/app/utils/types';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = environment.apiUrl;
  private url = `${this.apiUrl}/authenticate`;

  private token?: string;
  private user?: User;
  loginSignal = signal(false);
  private logoutTimer: any;

  constructor(private http: HttpClient) {
    this.initializeFromSessionStorage();
  }

  initializeFromSessionStorage() {
    const user = this.getUserFromSessionStorage();
    if (user) {
      this.loginSignal.set(true);
    }
  }

  setHeaders() {
    return new HttpHeaders({
      'Content-type': 'application/json',
      Authorization: `Bearer ${this.getToken()}`,
    });
  }

  authenticate(payload: LoginPayload): Observable<LoginSuccResonse> {
    const headers = this.setHeaders();
    return this.http
      .post<LoginSuccResonse>(this.url, payload, { headers })
      .pipe(
        tap((results: any) => {
          this.loginSignal.set(true);
          this.setToken(results.token);
          this.saveTokenToSessionStorage(results.token);
          this.setUser(results.user);
          this.saveUserToSessionStorage(results.user);
        })
      );
  }

  getUserDetails() {
    const headers = this.setHeaders();
    return this.http.get('/user').pipe(
      tap((results: any) => {
        
      })
    )
  }

  logout() {
    const headers = this.setHeaders();
    return this.http.get(`${this.apiUrl}/logout`, { headers }).pipe(
      tap((_) => {
        this.loginSignal.set(false);
        this.clearSessionStorage();
        this.user = undefined;
        this.token = undefined;
      }),
      catchError((error) => this.handleError(error))
    );
  }

  handleError(error: HttpErrorResponse): Observable<any> {
    throw error;
  }

  saveTokenToSessionStorage(token: string) {
    sessionStorage.setItem('token', token);
  }

  getTokenFromSessionStorage() {
    return sessionStorage.getItem('token');
  }

  saveUserToSessionStorage(user: User) {
    sessionStorage.setItem('user', JSON.stringify(user));
  }

  getUserFromSessionStorage(): User | undefined {
    const user = sessionStorage.getItem('user');
    if (user) {
      return JSON.parse(user);
    }
    return undefined;
  }

  clearSessionStorage() {
    sessionStorage.clear();
  }

  setToken(token: string) {
    this.token = token;
  }

  getToken() {
    if (this.token) {
      return this.token;
    }
    return this.getTokenFromSessionStorage();
  }

  setUser(user: User) {
    this.user = user;
  }

  getUser(): User | undefined {
    if (this.user) {
      return this.user;
    }
    return this.getUserFromSessionStorage();
  }
}
