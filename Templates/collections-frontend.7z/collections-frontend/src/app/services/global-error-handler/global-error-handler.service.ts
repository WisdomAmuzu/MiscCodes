import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { LoggingService } from '../logging/logging.service';
import { AuthService } from '../auth/auth.service';
@Injectable({
  providedIn: 'root'
})
export class GlobalErrorHandlerService {

  constructor(private injector: Injector) {}

  handleError(error: Error | HttpErrorResponse) {
    const loggingService = this.injector.get(LoggingService);

    let errorMessage: string;
    let stackTrace: string | undefined;

    if (error instanceof HttpErrorResponse) {
      // Server or connection error happened
      errorMessage = `Http error occurred: ${error.message}`;
      stackTrace = error.error instanceof Error ? error.error.stack : 'N/A';
    } else {
      // Client-side error
      errorMessage = `Client-side error occurred: ${error.message}`;
      stackTrace = error.stack || 'N/A';
    }

    // Log the error
    loggingService.logError(errorMessage, stackTrace);

    // Optionally rethrow the error
    // throw error;
  }
}
