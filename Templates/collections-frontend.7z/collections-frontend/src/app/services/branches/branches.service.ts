import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, tap, throwError } from 'rxjs';
import { Branch, Charge, GenericErrorResponse } from 'src/app/utils/types';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root',
})
export class BranchesService {
  private apiUrl = environment.apiUrl;
  private url = `${this.apiUrl}/branches`;

  constructor(private http: HttpClient, private auth: AuthService) {}

  setHeaders() {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
  }

  fetchBranch(id: number) {
    const headers = this.setHeaders();

    return this.http.get(`${this.url}/${id}`, { headers }).pipe(tap());
  }

  fetchBranches() {
    const headers = this.setHeaders();

    return this.http.get(this.url, { headers }).pipe(tap());
  }

  saveBranch(branch: Branch) {
    const headers = this.setHeaders();

    return this.http.post(this.url, branch, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  updateBranch(branch: Branch) {
    const headers = this.setHeaders();

    return this.http
      .patch(`${this.url}/${branch.id}`, branch, { headers })
      .pipe(
        tap(),
        catchError((error) => this.handleError(error))
      );
  }

  deleteBranch(id: number) {
    const headers = this.setHeaders();

    return this.http.delete(`${this.url}/${id}`, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  handleError(error: Error): Observable<GenericErrorResponse> {
    throw error;
  }
}
