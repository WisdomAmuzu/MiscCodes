import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, tap, throwError } from 'rxjs';
import {
  GenericErrorResponse,
  GenericSuccessResponse,
  Institution,
} from 'src/app/utils/types';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root',
})
export class InstitutionsService {
  private apiUrl = environment.apiUrl;
  private url = `${this.apiUrl}/institutions`;

  constructor(private http: HttpClient, private auth: AuthService) {}

  setHeaders() {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
  }

  fetchInstitution(id: number) {
    const headers = this.setHeaders();

    return this.http.get(`${this.url}/${id}`, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  fetchInstitutions() {
    const headers = this.setHeaders();

    return this.http.get(`${this.url}/list`, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  fetchInstitutionsAdmin() {
    const headers = this.setHeaders();

    return this.http.get(this.url, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  saveInstitution(institution: Institution): Observable<any> {
    const headers = this.setHeaders();

    return this.http.post<any>(this.url, institution, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  updateInstitution(institution: Institution) {
    const headers = this.setHeaders();

    return this.http
      .patch(`${this.url}/${institution.id}`, institution, { headers })
      .pipe(
        tap(),
        catchError((error) => this.handleError(error))
      );
  }

  deleteInstitution(id: number) {
    const headers = this.setHeaders();

    return this.http.delete(`${this.url}/${id}`, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  handleError(error: HttpErrorResponse): Observable<any> {
    // console.error('Error => ', error);
    throw error;
  }
}
