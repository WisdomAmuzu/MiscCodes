import { TestBed } from '@angular/core/testing';

import { InstituionsService } from './instituions.service';

describe('InstituionsService', () => {
  let service: InstituionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InstituionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
