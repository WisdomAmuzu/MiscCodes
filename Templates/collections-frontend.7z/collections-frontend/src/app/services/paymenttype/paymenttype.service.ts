import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap, throwError } from 'rxjs';
import {
  PaymentTypePayload,
} from 'src/app/utils/types';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root',
})
export class PaymenttypeService {
  private apiUrl = environment.apiUrl;
  private url = `${this.apiUrl}/paymenttypes`;

  constructor(private http: HttpClient, private auth: AuthService) {}

  setHeaders() {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
  }

  fetchPaymentType(id: number) {
    const headers = this.setHeaders();

    return this.http.get(`${this.url}/${id}`, { headers }).pipe(
      tap(),

      catchError((error) => this.handleError(error))
    );
  }

  fetchPaymentTypes(institution: string) {
    const headers = this.setHeaders();

    const params = {
      institution: institution,
    };
    return this.http.get(`${this.url}/list`, { headers, params }).pipe(
      tap(),

      catchError((error) => this.handleError(error))
    );
  }

  fetchPaymentTypesAdmin() {
    const headers = this.setHeaders();

    return this.http.get(this.url, { headers }).pipe(
      tap(),

      catchError((error) => this.handleError(error))
    );
  }

  savePaymentType(paymentType: PaymentTypePayload) {
    const headers = this.setHeaders();

    return this.http.post(this.url, paymentType, { headers }).pipe(
      tap(),

      catchError((error) => this.handleError(error))
    );
  }

  updatePaymentType(paymentType: PaymentTypePayload) {
    const headers = this.setHeaders();

    return this.http
      .patch(`${this.url}/${paymentType.id}`, paymentType, { headers })
      .pipe(
        tap(),

        catchError((error) => this.handleError(error))
      );
  }

  deletePaymentType(id: number) {
    const headers = this.setHeaders();

    return this.http.delete(`${this.url}/${id}`, { headers }).pipe(
      tap(),

      catchError((error) => this.handleError(error))
    );
  }

  handleError(error: HttpErrorResponse): Observable<any> {
    return throwError(() => error);
  }
}
