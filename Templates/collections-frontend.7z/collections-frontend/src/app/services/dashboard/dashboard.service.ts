import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth/auth.service';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { DashboardData } from 'src/app/utils/types';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private apiUrl = environment.apiUrl;
  private url = `${this.apiUrl}/dashboard`

  constructor(private http: HttpClient, private auth: AuthService) { }

  setHeaders() {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
  }

  getDashboardCounts<DashboardData>() {
    const headers = this.setHeaders();

    return this.http.get<Observable<DashboardData>>(this.url, { headers }).pipe(
      tap((_: any) => console.log('Dashboard data fetched'))
    )
  }
}
