// app/services/logging.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoggingService {
  constructor(private http: HttpClient) {}

  logError(message: string, stack: string | undefined) {
    const logEntry = {
      message,
      stack,
      url: window.location.href,
      userAgent: navigator.userAgent,
      timestamp: new Date().toISOString()
    };

    return this.http.post(`${environment.apiUrl}/api/log-frontend-error`, logEntry).subscribe(
      () => console.log('Error logged successfully'),
      err => console.error('Failed to log error', err)
    );
  }
}