import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, tap } from 'rxjs';
import { User, UserPayload } from 'src/app/utils/types';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class UsersService {
  private apiUrl = environment.apiUrl;
  private url = `${this.apiUrl}/users`;

  constructor(
    private http: HttpClient,
    private auth: AuthService,
    private router: Router
  ) {}

  setHeaders() {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
  }

  fetchUser(id: number) {
    const headers = this.setHeaders();

    return this.http.get(`${this.url}/${id}`, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  public fetchUsers() {
    const headers = this.setHeaders();

    return this.http
      .get(this.url, { headers })
      .pipe(tap());
  }

  public saveUser(user: UserPayload) {
    const headers = this.setHeaders();

    return this.http.post(this.url, user, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  public updateUser(user: UserPayload) {
    const headers = this.setHeaders();

    return this.http.patch(`${this.url}/${user.id}`, user, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  deleteUser(id: number) {
    const headers = this.setHeaders();

    return this.http.delete(`${this.url}/${id}`, { headers }).pipe(
      tap(),
      catchError((error) => this.handleError(error))
    );
  }

  handleError(error: HttpErrorResponse): Observable<any> {
    throw error;
  }
}
