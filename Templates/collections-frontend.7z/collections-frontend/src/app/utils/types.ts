export interface User {
  id?: number;
  username: string;
  fullname: string;
  status: string;
  usergroup: string;
  branch: number;
}

export interface UserAdmin {
  id?: number;
  username: string;
  fullname: string;
  status: string;
  usergroup: string;
  branch: Branch;
}

export interface UserPayload {
  id?: number;
  username: string;
  fullname: string;
  status: string;
  usergroup: string;
  branch: number | string;
}

export interface PaymentType {
  id?: number;
  name: string;
  institution: Institution;
  accountno: string;
}

export interface PaymentTypePayload {
  id?: number;
  name: string;
  institution: number | string;
  accountno: string;
}

export interface Payment {
  id?: number;
  institution: Institution;
  paymentmode: string;
  paymenttype: PaymentType;
  amount: number;
  description: string;
  customerphoneno: string;
  surname: string;
  othernames: string;
  // Optional, from server
  referenceno?: string;
  passportno?: string;
  customeremail?: string;
  tranid?: number;
  created_at?: number;
  teller?: User | number | string;
  status?: string;
  bbidentifier?: string;
  bbstatus?: string;
}

export interface PaymentPayload {
  id?: number;
  institution: number | string;
  paymentmethod?: string;
  paymenttype: number | string;
  amount: number;
  description: string;
  customerphoneno: string;
  surname: string;
  othernames: string;
  // Optional, from server
  referenceno?: string;
  passportno?: string;
  customeremail?: string;
  tranid?: number;
  created_at?: number;
  teller?: User | number | string;
  status?: string;
  bbidentifier?: string;
  bbstatus?: string;
}

export interface Reversal {
  id?: number;
  referenceno: string;
  payment: string;
  status: string;
  reason: string;
  created_at: string;
}

export interface ReversalPayload {
  payment: string;
  reason: string;
}

export interface ReportsPayload {
  start_date: string;
  end_date: string;
  branch?: number | string;
}

export interface Charge {
  id?: number;
  name: string;
  amount: number;
  // mandatory: boolean;
  institution: Institution;
  paymenttype: PaymentType;
}

export interface ChargePayload {
  id?: number;
  name: string;
  amount: number;
  // mandatory: boolean;
  institution: number | string;
  paymenttype: number | string;
}

export interface PaymentPostData {
  payment: PaymentPayload;
  charges: number[];
}

export interface Institution {
  id?: number;
  name: string;
}

export interface Branch {
  id?: number;
  name: string;
  branchcode?: string;
  sortcode?: string;
  suspaccno: string;
  cfrevaccounts?: string;
}

export interface LoginPayload {
  username: string;
  password: string;
}

export interface LoginSuccResonse {
  success: boolean;
  message: string;
  user: User;
  token: string;
  expires_at: string;
}

export interface PaymentSuccessResonse {
  success: string;
  message: string;
}

export interface GenericSuccessResponse {
  success: boolean;
  message: string;
}

export interface GenericErrorResponse {
  error: boolean;
  message: string;
}

export type DashboardData = {
  payments: {
    total: number,
    success: number;
    pending: number;
    reversed: number;
  };
  reversals: {
    pending: number;
  };
};
