import { Routes } from '@angular/router';
import { loginGuard } from './guards/login.guard';
import { tellerGuard } from './guards/teller.guard';
import { adminGuard } from './guards/admin.guard';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { branchGuard } from './guards/branch.guard';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { reporterGuard } from './guards/reporter.guard';
import { userGuard } from './guards/user.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/index', pathMatch: 'full' },
  // Index
  {
    path: 'index',
    loadComponent: () =>
      import('./pages/index/index.component').then((mod) => mod.IndexComponent),
    // canActivate: [loginGuard],
  },
  {
    path: 'login',
    loadComponent: () =>
      import('./pages/login/login.component').then((mod) => mod.LoginComponent),
    canActivate: [loginGuard],
  },
  {
    path: 'pay',
    loadComponent: () =>
      import('./pages/pay/pay.component').then((mod) => mod.PayComponent),
    canActivate: [tellerGuard],
  },
  // Institutions
  {
    path: 'institutions',
    loadComponent: () =>
      import('./pages/view-list/institutions/institutions.component').then(
        (mod) => mod.InstitutionsComponent
      ),
    canActivate: [adminGuard],
  },
  {
    path: 'institutions/add',
    loadComponent: () =>
      import('./pages/create/add-institution/add-institution.component').then(
        (mod) => mod.AddInstitutionComponent
      ),
    canActivate: [adminGuard],
  },

  {
    path: 'institutions/:id/update',
    loadComponent: () =>
      import(
        './pages/update/update-institution/update-institution.component'
      ).then((mod) => mod.UpdateInstitutionComponent),
    canActivate: [adminGuard],
  },
  // Payment types
  {
    path: 'paymenttypes',
    loadComponent: () =>
      import('./pages/view-list/paymenttype/paymenttype.component').then(
        (mod) => mod.PaymenttypeComponent
      ),
    canActivate: [adminGuard],
  },
  {
    path: 'paymenttypes/add',
    loadComponent: () =>
      import('./pages/create/add-paymenttype/add-paymenttype.component').then(
        (mod) => mod.AddPaymenttypeComponent
      ),
    canActivate: [adminGuard],
  },
  {
    path: 'paymenttypes/:id/update',
    loadComponent: () =>
      import(
        './pages/update/update-paymenttype/update-paymenttype.component'
      ).then((mod) => mod.UpdatePaymenttypeComponent),
    canActivate: [adminGuard],
  },
  // Branches
  {
    path: 'branches',
    loadComponent: () =>
      import('./pages/view-list/branches/branches.component').then(
        (mod) => mod.BranchesComponent
      ),
    canActivate: [adminGuard],
  },
  {
    path: 'branches/add',
    loadComponent: () =>
      import('./pages/create/add-branch/add-branch.component').then(
        (mod) => mod.AddBranchComponent
      ),
    canActivate: [adminGuard],
  },
  {
    path: 'branches/:id/update',
    loadComponent: () =>
      import('./pages/update/update-branch/update-branch.component').then(
        (mod) => mod.UpdateBranchComponent
      ),
    canActivate: [adminGuard],
  },
  // Users
  {
    path: 'users',
    loadComponent: () =>
      import('./pages/view-list/users-page/users-page.component').then(
        (mod) => mod.UsersPageComponent
      ),
    canActivate: [userGuard],
  },
  {
    path: 'users/add',
    loadComponent: () =>
      import('./pages/create/add-user/add-user.component').then(
        (mod) => mod.AddUserComponent
      ),
    canActivate: [userGuard],
  },
  {
    path: 'users/:id/update',
    loadComponent: () =>
      import('./pages/update/update-user/update-user.component').then(
        (mod) => mod.UpdateUserComponent
      ),
    canActivate: [userGuard],
  },
  // Charges
  {
    path: 'charges',
    loadComponent: () =>
      import('./pages/view-list/charges-page/charges-page.component').then(
        (mod) => mod.ChargesPageComponent
      ),
    canActivate: [adminGuard],
  },
  {
    path: 'charges/add',
    loadComponent: () =>
      import('./pages/create/add-charge/add-charge.component').then(
        (mod) => mod.AddChargeComponent
      ),
    canActivate: [adminGuard],
  },
  {
    path: 'charges/:id/update',
    loadComponent: () =>
      import('./pages/update/update-charge/update-charge.component').then(
        (mod) => mod.UpdateChargeComponent
      ),
    canActivate: [adminGuard],
  },
  // Report
  {
    path: 'reports',
    loadComponent: () =>
      import('./pages/reports/reports.component').then(
        (mod) => mod.ReportsComponent
      ),
    canActivate: [branchGuard],
  },
  {
    path: 'admin/reports',
    loadComponent: () =>
      import('./pages/admin-reports/admin-reports.component').then(
        (mod) => mod.AdminReportsComponent
      ),
    canActivate: [reporterGuard],
  },
  {
    path: 'admin/dashboard',
    component: DashboardComponent,
    canActivate: [adminGuard],
  },
  {
    path: '**',
    component: NotFoundComponent,
  },
];
