import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth/auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  const currentUser = inject(AuthService).getUser();
  const router = inject(Router);
  const loggedIn = inject(AuthService).loginSignal();

  if (currentUser || loggedIn) {
    return true
  }
  return router.parseUrl('/login')
};
