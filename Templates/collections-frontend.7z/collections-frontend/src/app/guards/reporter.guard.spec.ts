import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { reporterGuard } from './reporter.guard';

describe('reporterGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => reporterGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
