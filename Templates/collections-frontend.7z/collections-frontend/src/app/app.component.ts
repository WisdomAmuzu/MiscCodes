import { Component, OnDestroy, OnInit, effect } from '@angular/core';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { NgSwitch, NgSwitchDefault, NgSwitchCase, CommonModule } from '@angular/common';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';
import { AuthService } from './services/auth/auth.service';
import { User } from './utils/types';
import { HttpErrorResponse } from '@angular/common/http';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { MenuService } from 'ag-grid-community';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    NgSwitch,
    NgSwitchDefault,
    NgSwitchCase,
    RouterOutlet,
    RouterModule,
    MatToolbarModule,
    MatIconModule,
    MatSidenavModule,
    MatDividerModule,
    MatListModule,
    MatIconModule,
    NgxSpinnerModule,
  ],
  providers: [MenuService]
})
export class AppComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  title = 'vfs-app';
  opened = true;

  user?: User;
  // url = '';
  loggedIn?: any
  sidemenuOpened = true;

  constructor(
    private auth: AuthService,
    private router: Router,
    private spinner: NgxSpinnerService,
  ){
    effect(() => {
      if (this.auth.loginSignal() === true) {
        this.user = this.auth.getUser()
        this.opened = true;
      } else {
        this.auth.logout()
        this.user = undefined
        this.opened = false;
      } 
    })
  }

  ngOnInit(): void { 
    
  }

  ngOnDestroy(): void {
      this.subscription.unsubscribe()
  }

  toggleSideBar() {
    this.opened = !this.opened
  }

  login() {
    this.router.navigate(['/login'])
  }

  getUserDetails() {
    this.subscription.add(
      this.auth.getUserDetails().subscribe({
        next: (result: any) => {
          this.user = result
        },
        error: (error) => {
          this.handleError(error)
        }
      })
    )
  }

  logout() {
    this.spinner.show()
    this.subscription.add(
      this.auth.logout().subscribe({
        next: ((result:any) => {
          this.user = undefined
          this.opened = false;
          this.spinner.hide()
          this.router.navigateByUrl('/login')
        }),
        error: (error: HttpErrorResponse) => {
          this.handleError(error)
        },
      })
    )
    
  }

  handleError(error: HttpErrorResponse) {
    this.spinner.hide()
    if (error.status == 401) {
      this.auth.clearSessionStorage();
      this.refresh()

    }
    if (error.status == 403) {
      alert("You don't have access to the requested resource")
    }
    if (error.status == 500) {
      alert(error.error.message)
    }
  }

  refresh(): void {
    window.location.reload();
  }

}
